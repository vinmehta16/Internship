import urllib2
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText

flag = 1
while (flag == 1):
    try:
      urllib2.urlopen("https://www.google.com/")
    except urllib2.URLError, e:
      print "Network down."
    else:
      print "Up and running."
      flag = 0
      fromaddr = "vmehta@bio-botanica.com"
      toaddr = "jmcmanus@bio-botanica.com"
      msg = MIMEMultipart()
      msg['From'] = fromaddr
      msg['To'] = toaddr
      msg['Subject'] = "GOOD NEWS!!!"
      body = "THE WIFI SYSTEM IS UP AND RUNNING"
      msg.attach(MIMEText(body, 'plain'))
      server = smtplib.SMTP('smtp.gmail.com', 587)
      server.starttls()
      server.login(fromaddr, "Pinpushers!")
      text = msg.as_string()
      server.sendmail(fromaddr, toaddr, text)
      server.quit()