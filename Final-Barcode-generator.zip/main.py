import barcode
from barcode.writer import ImageWriter 
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm, inch
import datetime
from datetime import datetime
from pytz import timezone


def barcode_generator():
  pageHeight = 8.5
  pageWidth = 11
  point = 1
  c = canvas.Canvas('label.pdf', pagesize = (pageWidth*70, pageHeight*70))

  num = input("Enter Order Number:")
  image = barcode.get('code128',num, writer = ImageWriter())
  image_bar = image.save('barcode.png')
  image_bar
  expirationPeriod = input("Enter the Expiration Period (All in Caps):")
  orderQuantity = input("Enter the Order Quantity:")
  orderDate = input('Enter the Order Date(mm/dd/yyyy):')
  try:
    numLines = int(input("Enter the Total number of lines needed:"))
  except ValueError:
    print("Enter a number")
    numLines = int(input("Enter the Total number of lines needed:"))
  
  companyName = input("Enter the Company name (All in caps):")
  orderDueDate = input("Enter the Order Due Date(mm/dd/yyy):")
  typeOfBusiness = input("Enter the type of business(Ecommerce, etc):")
  companyID = input("Enter the Company ID:")

  c.drawImage('barcode.png.png', 270, 230, 10*cm, 3*cm)
  c.setFont("Helvetica", 14 * point)
  c.drawString(100, 550, expirationPeriod)
  c.drawString(600, 550, "Order Date: {0}".format(orderDate))
  c.drawString(600, 530, "Order Quantity: {0}".format(orderQuantity))
  c.drawString(600, 510, "Total Lines: {0}".format(str(numLines)))
  c.drawString(365, 420, companyID)
  c.setFont("Helvetica-Bold", 20 * point)  
  c.drawString(250, 380, companyName)
  c.setFont("Helvetica", 14 * point)
  c.drawString(360, 350, typeOfBusiness)
  c.drawString(370, 330, "ORDER ID:")
  fmt = "%I:%M %p"
  ftm = "%m/%d/%Y"
  now_utc = datetime.now(timezone('UTC'))
  now_eastern = now_utc.astimezone(timezone('US/Eastern'))
  c.drawString(600, 100, "Print Date: {0}".format(now_eastern.strftime(ftm)))
  c.drawString(600, 80, "Print Time: {0}".format(now_eastern.strftime(fmt)))
  c.drawString(365, 100, "Order Due Date:")
  c.drawString(380, 80, orderDueDate)
  c.drawString(360, 200,"ORDER#:{0}".format(str(num)))

  c.rect(70, 545, 230, 30)
  c.rect(0, 375, 2000, 35)
  c.rect(580, 500, 175, 70)
  c.line(0, 2*inch, 20*inch, 2*inch)
  c.showPage()
  c.save()
  return 'Barcode Created'

barcode_generator()