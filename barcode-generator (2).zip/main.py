import barcode
import random
from barcode.writer import ImageWriter 
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
import datetime
from datetime import datetime
from pytz import timezone

def barcode_generator():
  num = input("Enter Order Number:")#random.randrange(1, 10000000)
  print(num)
  image = barcode.get('code128',num, writer = ImageWriter())
  image_bar = image.save('barcode.png')
  image_bar
  expirationPeriod = input("Enter the Expiration Period (All in Caps):")
  orderQuantity = input("Enter the Order Quantity:")
  orderDate = input('Enter the Order Date(mm/dd/yyyy):')
  try:
    numLines = int(input("Enter the Total number of lines needed:"))
  except ValueError:
    print("Enter a number")
    numLines = int(input("Enter the Total number of lines needed:"))
  
  companyName = input("Enter the Company name (All in caps):")
  orderDueDate = input("Enter the Order Due Date(mm/dd/yyy):")
  typeOfBusiness = input("Enter the type of business(Ecommerce, etc):")
  companyID = input("Enter the Company ID:")

  c = canvas.Canvas('label.pdf')
  c.drawImage('barcode.png.png', 150, 360, 10*cm, 3*cm)
  c.drawString(80, 600, expirationPeriod)
  c.drawString(400, 600, "Order Date: {0}".format(orderDate))
  c.drawString(400, 580, "Order Quantity: {0}".format(orderQuantity))
  c.drawString(400, 560, "Total Lines: {0}".format(str(numLines)))
  c.drawString(230, 530, companyID)  
  c.drawString(200, 500, companyName)
  c.drawString(230, 470, typeOfBusiness)
  c.drawString(245, 450, "ORDER ID:")


  #now = datetime.datetime.now()
  fmt = "%I:%M %p"
  ftm = "%m/%d/%Y"
  now_utc = datetime.now(timezone('UTC'))
  now_eastern = now_utc.astimezone(timezone('US/Eastern'))
  c.drawString(430, 300, "Print Date: {0}".format(now_eastern.strftime(ftm)))
  c.drawString(430, 280, "Print Time: {0}".format(now_eastern.strftime(fmt)))
  c.drawString(250, 300, "Order Due Date:")
  c.drawString(260, 280, orderDueDate)
  c.drawString(240, 340,"ORDER#:{0}".format(str(num)))
  c.showPage()
  c.save()
  return 'Barcode Created'
 