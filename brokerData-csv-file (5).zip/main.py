import csv

fileName = input("Enter csv file name you would like to open:")

with open(fileName) as csvfile:
  with open('BrokerData.csv', 'w') as csv_file:
    reader = csv.DictReader(csvfile)
    writer = csv.writer(csv_file)
    writer.writerow(['Broker' , 'May' , 'June' , 'July' , 'August' , 'September' , 'October'])
    #ejhcount = 0
    mountainMay = 0
    mountainJune = 0
    mountainJuly = 0
    mountainAug = 0
    mountainSept = 0
    mountainOct = 0

    presenceMay = 0
    presenceJune = 0
    presenceJuly = 0
    presenceAug = 0
    presenceSept = 0
    presenceOct = 0

    natureMay = 0
    natureJune = 0
    natureJuly = 0
    natureAug = 0
    natureSept = 0
    natureOct = 0

    pNEMay = 0
    pNEJune = 0
    pNEJuly = 0
    pNEAug = 0
    pNESept = 0
    pNEOct = 0

    pNAMay = 0
    pNAJune = 0
    pNAJuly = 0
    pNAAug = 0
    pNASept = 0
    pNAOct = 0

    pCAMay = 0
    pCAJune = 0
    pCAJuly = 0
    pCAAug = 0
    pCASept = 0
    pCAOct = 0

    ejhMay = 0
    ejhJune = 0
    ejhJuly = 0
    ejhAug = 0
    ejhSept = 0
    ejhOct = 0
    
    preMAMay = 0
    preMAJune = 0
    preMAJuly = 0
    preMAAug = 0
    preMASept = 0
    preMAOct = 0

    horMay = 0
    horJune = 0
    horJuly = 0
    horAug = 0
    horSept = 0
    horOct = 0

    for row in reader:
      if "ID" in row['Territory']:
        mountainMay += float(row['May'])
        
      if "MT" in row['Territory']:
        mountainMay += float(row['May'])
        
      if "OR" in row['Territory']:
        mountainMay += float(row['May'])

      if "WA" in row['Territory']:
        mountainMay += float(row['May'])
        

      if "ID" in row['Territory']:
        mountainJune += float(row['June'])
        
      if "MT" in row['Territory']:
        mountainJune += float(row['June'])
        
      if "OR" in row['Territory']:
        mountainJune += float(row['June'])

      if "WA" in row['Territory']:
        mountainJune += float(row['June'])


      if "ID" in row['Territory']:
        mountainJuly += float(row['July'])
        
      if "MT" in row['Territory']:
        mountainJuly += float(row['July'])
        
      if "OR" in row['Territory']:
        mountainJuly += float(row['July'])

      if "WA" in row['Territory']:
        mountainJuly += float(row['July'])


      if "ID" in row['Territory']:
        mountainAug += float(row['August'])
        
      if "MT" in row['Territory']:
        mountainAug += float(row['August'])
        
      if "OR" in row['Territory']:
        mountainAug += float(row['August'])

      if "WA" in row['Territory']:
        mountainAug += float(row['August'])


      if "ID" in row['Territory']:
        mountainSept += float(row['September'])
        
      if "MT" in row['Territory']:
        mountainSept += float(row['September'])
        
      if "OR" in row['Territory']:
        mountainSept += float(row['September'])

      if "WA" in row['Territory']:
        mountainSept += float(row['September'])
      

      if "ID" in row['Territory']:
        mountainOct += float(row['October'])
        
      if "MT" in row['Territory']:
        mountainOct += float(row['October'])
        
      if "OR" in row['Territory']:
        mountainOct += float(row['October'])

      if "WA" in row['Territory']:
        mountainOct += float(row['October'])
        writer.writerow(['Mountain Sales - Northwest Region', mountainMay, mountainJune, mountainJuly, mountainAug, mountainSept, mountainOct])


      if "AZ" in row['Territory']:
        presenceMay += float(row['May'])
        
      if "CO" in row['Territory']:
        presenceMay += float(row['May'])
        
      if "NM" in row['Territory']:
        presenceMay += float(row['May'])
      
      if "NV" in row['Territory']:
        presenceMay += float(row['May'])

      if "UT" in row['Territory']:
        presenceMay += float(row['May'])


      if "AZ" in row['Territory']:
        presenceJune += float(row['June'])
        
      if "CO" in row['Territory']:
        presenceJune += float(row['June'])
        
      if "NM" in row['Territory']:
        presenceJune += float(row['June'])
      
      if "NV" in row['Territory']:
        presenceJune += float(row['June'])

      if "UT" in row['Territory']:
       presenceJune += float(row['June'])


      if "AZ" in row['Territory']:
        presenceJuly += float(row['July'])
        
      if "CO" in row['Territory']:
        presenceJuly += float(row['July'])
        
      if "NM" in row['Territory']:
        presenceJuly += float(row['July'])
      
      if "NV" in row['Territory']:
        presenceJuly += float(row['July'])

      if "UT" in row['Territory']:
        presenceJuly += float(row['July'])
      

      if "AZ" in row['Territory']:
        presenceAug += float(row['August'])
        
      if "CO" in row['Territory']:
        presenceAug += float(row['August'])
        
      if "NM" in row['Territory']:
        presenceAug += float(row['August'])
      
      if "NV" in row['Territory']:
        presenceAug += float(row['August'])

      if "UT" in row['Territory']:
        presenceAug += float(row['August'])


      if "AZ" in row['Territory']:
        presenceSept += float(row['September'])
        
      if "CO" in row['Territory']:
        presenceSept += float(row['September'])
        
      if "NM" in row['Territory']:
        presenceSept += float(row['September'])
      
      if "NV" in row['Territory']:
        presenceSept += float(row['September'])

      if "UT" in row['Territory']:
        presenceSept += float(row['September'])
      

      if "AZ" in row['Territory']:
        presenceOct += float(row['October'])
        
      if "CO" in row['Territory']:
        presenceOct += float(row['October'])
        
      if "NM" in row['Territory']:
        presenceOct += float(row['October'])
      
      if "NV" in row['Territory']:
        presenceOct += float(row['October'])

      if "UT" in row['Territory']:
        presenceOct += float(row['October'])
        writer.writerow(['Presence Marketing - RMP', presenceMay, presenceJune, presenceJuly, presenceAug, presenceSept, round(presenceOct,2)])


      if "AL" in row['Territory']:
        natureMay += float(row['May'])
        
      if "FL" in row['Territory']:
        natureMay += float(row['May'])
        
      if "GA" in row['Territory']:
        natureMay += float(row['May'])
      
      if "MS" in row['Territory']:
        natureMay += float(row['May'])
      
      if "NC" in row['Territory']:
        natureMay += float(row['May'])
    
      if "SC" in row['Territory']:
        natureMay += float(row['May'])

      if "TN" in row['Territory']:
        natureMay += float(row['May'])

      if "VA" in row['Territory']:
        natureMay += float(row['May'])


      if "AL" in row['Territory']:
        natureJune += float(row['June'])
        
      if "FL" in row['Territory']:
        natureJune += float(row['June'])
        
      if "GA" in row['Territory']:
        natureJune += float(row['June'])

      if "MS" in row['Territory']:
        natureJune += float(row['June'])
      
      if "NC" in row['Territory']:
        natureJune += float(row['June'])
    
      if "SC" in row['Territory']:
        natureJune += float(row['June'])

      if "TN" in row['Territory']:
        natureJune += float(row['June'])

      if "VA" in row['Territory']:
        natureJune += float(row['June'])


      if "AL" in row['Territory']:
        natureJuly += float(row['July'])
        
      if "FL" in row['Territory']:
        natureJuly += float(row['July'])
        
      if "GA" in row['Territory']:
        natureJuly += float(row['July'])

      if "MS" in row['Territory']:
        natureJuly += float(row['July'])
      
      if "NC" in row['Territory']:
        natureJuly += float(row['July'])
    
      if "SC" in row['Territory']:
        natureJuly += float(row['July'])

      if "TN" in row['Territory']:
        natureJuly += float(row['July'])

      if "VA" in row['Territory']:
        natureJuly += float(row['July'])

      
      if "AL" in row['Territory']:
        natureAug += float(row['August'])
        
      if "FL" in row['Territory']:
        natureAug += float(row['August'])
        
      if "GA" in row['Territory']:
        natureAug += float(row['August'])

      if "MS" in row['Territory']:
        natureAug += float(row['August'])
      
      if "NC" in row['Territory']:
        natureAug += float(row['August'])
    
      if "SC" in row['Territory']:
        natureAug += float(row['August'])

      if "TN" in row['Territory']:
        natureAug += float(row['August'])

      if "VA" in row['Territory']:
        natureAug += float(row['August'])


      if "AL" in row['Territory']:
        natureSept += float(row['September'])
        
      if "FL" in row['Territory']:
        natureSept += float(row['September'])
        
      if "GA" in row['Territory']:
        natureSept += float(row['September'])

      if "MS" in row['Territory']:
        natureSept += float(row['September'])
      
      if "NC" in row['Territory']:
        natureSept += float(row['September'])
    
      if "SC" in row['Territory']:
        natureSept += float(row['September'])

      if "TN" in row['Territory']:
        natureSept += float(row['September'])

      if "VA" in row['Territory']:
        natureSept += float(row['September'])
      
      
      if "AL" in row['Territory']:
        natureOct += float(row['October'])
        
      if "FL" in row['Territory']:
        natureOct += float(row['October'])
        
      if "GA" in row['Territory']:
        natureOct += float(row['October'])

      if "MS" in row['Territory']:
        natureOct += float(row['October'])
      
      if "NC" in row['Territory']:
        natureOct += float(row['October'])
    
      if "SC" in row['Territory']:
        natureOct += float(row['October'])

      if "TN" in row['Territory']:
        natureOct += float(row['October'])

      if "VA" in row['Territory']:
        natureOct += float(row['October'])
        writer.writerow(['Natures Trading - South East', natureMay, natureJune, natureJuly, round(natureAug,2), natureSept, natureOct])


      if "NJ" in row['Territory']:
        pNEMay += float(row['May'])

      if "NY" in row['Territory']:
        pNEMay += float(row['May'])
      
      
      if "NJ" in row['Territory']:
        pNEJune += float(row['June'])

      if "NY" in row['Territory']:
        pNEJune += float(row['June'])

      
      if "NJ" in row['Territory']:
        pNEJuly += float(row['July'])

      if "NY" in row['Territory']:
        pNEJuly += float(row['July'])

      
      if "NJ" in row['Territory']:
        pNEAug += float(row['August'])

      if "NY" in row['Territory']:
        pNEAug += float(row['August'])


      if "NJ" in row['Territory']:
        pNESept += float(row['September'])

      if "NY" in row['Territory']:
        pNESept += float(row['September'])
      

      if "NJ" in row['Territory']:
        pNEOct += float(row['October'])

      if "NY" in row['Territory']:
        pNEOct += float(row['October'])
        writer.writerow(['Precision Sales - North East', pNEMay, pNEJune, pNEJuly, pNEAug, round(pNESept,2), pNEOct])


      if "CT" in row['Territory']:
        pNAMay += float(row['May'])
        
      if "ME" in row['Territory']:
        pNAMay += float(row['May'])
        
      if "MA" in row['Territory']:
        pNAMay += float(row['May'])
      
      if "NH" in row['Territory']:
        pNAMay += float(row['May'])
      
      if "RI" in row['Territory']:
        pNAMay += float(row['May'])
    
      if "VT" in row['Territory']:
        pNAMay += float(row['May'])

      
      if "CT" in row['Territory']:
        pNAJune += float(row['June'])
        
      if "ME" in row['Territory']:
        pNAJune += float(row['June'])
        
      if "MA" in row['Territory']:
        pNAJune += float(row['June'])
      
      if "NH" in row['Territory']:
        pNAJune += float(row['June'])
      
      if "RI" in row['Territory']:
        pNAJune += float(row['June'])
    
      if "VT" in row['Territory']:
        pNAJune += float(row['June'])

      
      if "CT" in row['Territory']:
        pNAJuly += float(row['July'])
        
      if "ME" in row['Territory']:
        pNAJuly += float(row['July'])
        
      if "MA" in row['Territory']:
        pNAJuly += float(row['July'])
      
      if "NH" in row['Territory']:
        pNAJuly += float(row['July'])
      
      if "RI" in row['Territory']:
        pNAJuly += float(row['July'])
    
      if "VT" in row['Territory']:
        pNAJuly += float(row['July'])

      
      if "CT" in row['Territory']:
        pNAAug += float(row['August'])
        
      if "ME" in row['Territory']:
        pNAAug += float(row['August'])
        
      if "MA" in row['Territory']:
        pNAAug += float(row['August'])
      
      if "NH" in row['Territory']:
        pNAAug += float(row['August'])
      
      if "RI" in row['Territory']:
        pNAAug += float(row['August'])
    
      if "VT" in row['Territory']:
        pNAAug += float(row['August'])

      
      if "CT" in row['Territory']:
        pNASept += float(row['September'])
        
      if "ME" in row['Territory']:
        pNASept += float(row['September'])
        
      if "MA" in row['Territory']:
        pNASept += float(row['September'])
      
      if "NH" in row['Territory']:
        pNASept += float(row['September'])
      
      if "RI" in row['Territory']:
        pNASept += float(row['September'])
    
      if "VT" in row['Territory']:
        pNASept += float(row['September'])

      
      if "CT" in row['Territory']:
        pNAOct += float(row['October'])
        
      if "ME" in row['Territory']:
        pNAOct += float(row['October'])
        
      if "MA" in row['Territory']:
        pNAOct += float(row['October'])
      
      if "NH" in row['Territory']:
        pNAOct += float(row['October'])
      
      if "RI" in row['Territory']:
        pNAOct += float(row['October'])
    
      if "VT" in row['Territory']:
        pNAOct += float(row['October'])
        writer.writerow(['Precision Sales - North Atlantic', pNAMay, round(pNAJune,2), round(pNAJuly,2), round(pNAAug,2), pNASept, pNAOct])

      if "CA" in row['Territory']:
        pCAMay += float(row['May'])
        pCAJune += float(row['June'])
        pCAJuly += float(row['July'])
        pCAAug += float(row['August'])
        pCASept += float(row['September'])
        pCAOct += float(row['October'])
        writer.writerow(['Presence Marketing - Northern CA' , float(pCAMay)/2, float(pCAJune)/2, float(pCAJuly)/2, float(pCAAug)/2, float(pCASept)/2, float(pCAOct)/2])

      if "CA" in row['Territory']:
        ejhMay += float(row['May'])
        ejhJune += float(row['June'])
        ejhJuly += float(row['July'])
        ejhAug += float(row['August'])
        ejhSept += float(row['September'])
        ejhOct += float(row['October'])
        writer.writerow(['EJH - Southern CA', float(ejhMay)/2, float(ejhJune)/2, float(ejhJuly)/2, float(ejhAug)/2, float(ejhSept)/2, float(ejhOct)/2])

      if "DC" in row['Territory']:
        preMAMay += float(row['May'])
        
      if "DE" in row['Territory']:
        preMAMay += float(row['May'])
        
      if "MD" in row['Territory']:
        preMAMay += float(row['May'])

      if "PA" in row['Territory']:
        preMAMay += float(row['May'])/2
        

      if "DC" in row['Territory']:
        preMAJune += float(row['June'])
        
      if "DE" in row['Territory']:
        preMAJune += float(row['June'])
        
      if "MD" in row['Territory']:
        preMAJune += float(row['June'])

      if "PA" in row['Territory']:
        preMAJune += float(row['June'])/2


      if "DC" in row['Territory']:
        preMAJuly += float(row['July'])
        
      if "DE" in row['Territory']:
        preMAJuly += float(row['July'])
        
      if "MD" in row['Territory']:
        preMAJuly += float(row['July'])

      if "PA" in row['Territory']:
        preMAJuly += float(row['July'])/2


      if "DC" in row['Territory']:
        preMAAug += float(row['August'])
        
      if "DE" in row['Territory']:
        preMAAug += float(row['August'])
        
      if "MD" in row['Territory']:
        preMAAug += float(row['August'])

      if "PA" in row['Territory']:
        preMAAug += float(row['August'])


      if "DC" in row['Territory']:
        preMASept += float(row['September'])
        
      if "DE" in row['Territory']:
        preMASept += float(row['September'])
        
      if "MD" in row['Territory']:
        preMASept += float(row['September'])

      if "PA" in row['Territory']:
        preMASept += float(row['September'])
      

      if "DC" in row['Territory']:
        preMAOct += float(row['October'])
        
      if "DE" in row['Territory']:
        preMAOct += float(row['October'])
        
      if "MD" in row['Territory']:
        preMAOct += float(row['October'])

      if "PA" in row['Territory']:
        preMAOct += float(row['October'])
        writer.writerow(['Precision Sales - Mid Atlantic', round(float(preMAMay),2), round(float(preMAJune), 2), round(float(preMAJuly),2), float(preMAAug)/2, float(preMASept)/2, float(preMAOct)/2])


      if "AR" in row['Territory']:
        horMay += float(row['May'])
        
      if "KS" in row['Territory']:
        horMay += float(row['May'])
        
      if "LA" in row['Territory']:
        horMay += float(row['May'])
      
      if "OK" in row['Territory']:
        horMay += float(row['May'])
      
      if "TX" in row['Territory']:
        horMay += float(row['May'])
    
      if "MO" in row['Territory']:
        horMay += (float(row['May'])/2)
        
      
      if "AR" in row['Territory']:
        horJune += float(row['June'])
        
      if "KS" in row['Territory']:
        horJune += float(row['June'])
        
      if "LA" in row['Territory']:
        horJune += float(row['June'])
      
      if "OK" in row['Territory']:
        horJune += float(row['June'])
      
      if "TX" in row['Territory']:
        horJune += float(row['June'])
    
      if "MO" in row['Territory']:
        horJune += float(row['June'])/2

      
      if "AR" in row['Territory']:
        horJuly += float(row['July'])
        
      if "KS" in row['Territory']:
        horJuly += float(row['July'])
        
      if "LA" in row['Territory']:
        horJuly += float(row['July'])
      
      if "OK" in row['Territory']:
        horJuly += float(row['July'])
      
      if "TX" in row['Territory']:
        horJuly += float(row['July'])
    
      if "MO" in row['Territory']:
        pNAJuly += float(row['July'])/2

      
      if "AR" in row['Territory']:
        horAug += float(row['August'])
        
      if "KS" in row['Territory']:
        horAug += float(row['August'])
        
      if "LA" in row['Territory']:
        horAug += float(row['August'])
      
      if "OK" in row['Territory']:
        horAug += float(row['August'])
      
      if "TX" in row['Territory']:
        horAug += float(row['August'])
    
      if "MO" in row['Territory']:
        horAug += float(row['August'])/2

      
      if "AR" in row['Territory']:
        horSept += float(row['September'])
        
      if "KS" in row['Territory']:
        horSept += float(row['September'])
        
      if "LA" in row['Territory']:
        horSept += float(row['September'])
      
      if "OK" in row['Territory']:
        horSept += float(row['September'])
      
      if "TX" in row['Territory']:
        horSept += float(row['September'])
    
      if "MO" in row['Territory']:
        horSept += float(row['September'])/2
      

      if "AR" in row['Territory']:
        horOct += float(row['October'])
        
      if "KS" in row['Territory']:
        horOct += float(row['October'])
        
      if "LA" in row['Territory']:
        horOct += float(row['October'])
      
      if "OK" in row['Territory']:
        horOct += float(row['October'])
      
      if "TX" in row['Territory']:
        horOct += float(row['October'])
    
      if "MO" in row['Territory']:
        horOct += float(row['October'])/2
        writer.writerow(['Horizon Marketing - South West Region', float(horMay), float(horJune), float(horJuly), round(float(horAug),2), round(float(horSept),2), float(horOct)])


    


    

    
      


    


    
      

    
      #print(row['Total'])
    #state_list = row['Territory']
    #price_list = row['Total']
  #print(state_list)
  #print(price_list)
  #for state in state_list:
    #if "ALABAMA" in state:
      #print('2')
  #count += float(price_list)
  #print(round(count,1))
    #new_list.append(state)
    
    #print("2")
    #print(state_list)
    
    #for state_list in row['Territory']:
      #print("1")
      #ejhCount = 0
      #ejhCount += float(row['Total'])
  #print(ejhCount)
      #total = [row['May 17 - Oct 17']]
      #total = row['May 17 - Oct 17']
      #print(' ')
      #print(state, float(total))
